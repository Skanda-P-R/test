import requests

def send_to_groq(user_prompt, api_url):
    headers = {
        "Content-Type": "application/json",
        "Authorization": f"Bearer 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"
    }

    payload = {
        "model": "openai/gpt-oss-120b",
        "messages": [
            {"role": "system", "content": "You are an AI that answers questions based on the Heatwaves."},
            {"role": "user", "content": "Question : " + user_prompt}
        ]
    }

    try:
        response = requests.post(api_url, headers=headers, json=payload)
        response.raise_for_status()
        
        response_json = response.json()
        
        content = response_json.get("choices", [{}])[0].get("message", {}).get("content", "")
        
        return content
    except requests.exceptions.RequestException as e:
        return {"error": str(e)}

